import React from "react";
import ReactDOM from "react-dom";
import Star from "./Star";

ReactDOM.render(
  <React.StrictMode>
    <Star />
  </React.StrictMode>,
  document.getElementById("root")
);
